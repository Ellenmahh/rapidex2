package br.com.tourdreams.app.cmlibrary;

/**
 * 点击子菜单项按钮的回调接口
 *
 * Created by hitomi on 2016/10/9.
 */
public interface OnMenuSelectedListener {

    void onMenuSelected(int index);

}
