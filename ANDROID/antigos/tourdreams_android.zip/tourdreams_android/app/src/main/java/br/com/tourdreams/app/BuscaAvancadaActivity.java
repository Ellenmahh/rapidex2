package br.com.tourdreams.app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class BuscaAvancadaActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        definirConteudo(R.layout.activity_busca_avancada);
    }
}
