package br.com.tourdreams.app;

/**
 * Created by 15251365 on 25/10/2017.
 */

public class Promocao {
    private int id_promocao;
    private String banner_promocao;
    private int status_promocao;

    public int getId_promocao() {
        return id_promocao;
    }

    public void setId_promocao(int id_promocao) {
        this.id_promocao = id_promocao;
    }

    public String getBanner_promocao() {
        return banner_promocao;
    }

    public void setBanner_promocao(String banner_promocao) {
        this.banner_promocao = banner_promocao;
    }

    public int getStatus_promocao() {
        return status_promocao;
    }

    public void setStatus_promocao(int status_promocao) {
        this.status_promocao = status_promocao;
    }
}

